"""
this file provides the handler for processing the data so that it can be used by tensorflow models
"""