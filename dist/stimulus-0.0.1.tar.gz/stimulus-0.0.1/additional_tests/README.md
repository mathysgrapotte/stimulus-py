This directory is for python tests that do not fit with the nextflow + unittest directory organization.
Or any other test file that is intended to be run every time a PR is merged.